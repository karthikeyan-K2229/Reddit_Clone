import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SubredditModel } from '../subreddit';
import { Router } from '@angular/router';
import { PostService } from '../post.service';
import { SubredditService } from '../subreddit.service';


@Component({
  selector: 'app-create-post',
  templateUrl: './create-post.component.html',
  styleUrl: './create-post.component.css'
})
export class CreatePostComponent {
  
  subreddits!:SubredditModel[];
  createPostForm:any;

  constructor(private router: Router, private postService: PostService,
    private subredditService: SubredditService,private formBuilder: FormBuilder) {
      this.forms();
    }


  ngOnInit() {
    this.getAllSubreddit();
  }

  public getAllSubreddit()
  {
    this.subredditService.getAllSubreddits().subscribe((data:any)=>
      {
        this.subreddits=data;
      })
  }

  forms() {
    this.createPostForm = this.formBuilder.group({
      postName: ['',Validators.required],
      subredditName: ['',Validators.required],
      url: ['', Validators.required],
      description: ['', Validators.required],
      userId:[localStorage.getItem('userId')]
    });
  }

  createPost(){
  console.log(this.createPostForm.value);
  this.postService.createPost(this.createPostForm.value).subscribe(
 data=>
 {
   console.log(data)
 alert("Post Saved Successfully");
 this.router.navigate(['/Home']);
  },
  (error:{error:any;})=>{
   console.log(" Failed");
   alert(" Failed");
   
  })
}
discardPost() {
  this.router.navigateByUrl('/Home');
}
}