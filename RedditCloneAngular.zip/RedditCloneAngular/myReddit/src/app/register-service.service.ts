import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { signup } from './signup/signup';
import { HttpClient } from '@angular/common/http';
import { environment } from './environments/environment';

const API = environment.apiURL;
@Injectable({
  providedIn: 'root'
})
export class RegisterServiceService {
 

  constructor(private httpClient: HttpClient)
  {}

  public registerUser(user: signup) :Observable<object>
  {
    console.log(user);
    return this.httpClient.post(`${API}/register`,user);
  }
}
