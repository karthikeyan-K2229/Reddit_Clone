import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CommentPayload } from './comment-payload';
import { Observable } from 'rxjs';
import { environment } from './environments/environment';


const API = environment.apiURL;
@Injectable({
  providedIn: 'root'
})
export class CommentService {

  constructor(private httpClient: HttpClient) { }

  getAllCommentsForPost(postId: number): Observable<CommentPayload[]> {
    return this.httpClient.get<CommentPayload[]>(`${API}/by-post/` + postId);
  }

  postComment(commentPayload: CommentPayload): Observable<any> {
    return this.httpClient.post<any>(`${API}/postComment`, commentPayload);
  }

  // getAllCommentsByUser(name: string) {
  //   return this.httpClient.get<CommentPayload[]>('http://localhost:8080/api/comments/by-user/' + name);
  // }
}
