import { Component } from '@angular/core';
import { RegisterServiceService } from '../register-service.service';
import { Router } from '@angular/router';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrl: './signup.component.css'
})
export class SignupComponent {
  isSignDivVisiable: boolean  = true;
  public RegisterForm: any;
  submitted:boolean=false;

  constructor(private registerService: RegisterServiceService,
    private _router : Router,
    private formBuilder: FormBuilder) { 
      this.forms();
    }




    forms() {
      this.RegisterForm = this.formBuilder.group({
        email: ['', [Validators.required,Validators.email]],
        password: ['', [Validators.minLength(8),Validators.maxLength(16),Validators.required]],
        username: ['', Validators.required]
      });
    }




  userRegister()
{ 
             this.submitted = true;
            if (this.RegisterForm.invalid) 
              {
             alert("Enter all details");
            return;
              }
    
     console.log(this.RegisterForm.value);
     this.registerService.registerUser(this.RegisterForm.value).subscribe(
    data=>
    {
      console.log(data)
    alert("Registration successfull");
    this._router.navigate(['/login']);
     },
     (error:{error:any;})=>{
      console.log("Registration Failed");
      alert("Registration Failed");
      
     })
 }
}
