export class signup
{
    userId!:number;
    email!:string;
    password!:string;
    username!:string;
    created!:Date;
    enabled!:boolean

}