import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { PostModel } from './postModel';
import { CreatePostPayload } from './create-post/create-post';
import { environment } from './environments/environment';

const API = environment.apiURL;

@Injectable({
  providedIn: 'root'
})
export class PostService {
  
  
  constructor(private http: HttpClient) { }

  getAllPosts() : Observable<Array<PostModel>>{
    return this.http.get<Array<PostModel>>(`${API}/api/getAllposts`);
  }

  createPost(postPayload: CreatePostPayload): Observable<any> {
    return this.http.post(`${API}/api/SavePosts`,postPayload);
  }

  getPost(id : number):Observable<PostModel>{
    return this.http.get<PostModel>(`${API}/api/posts/`+id);
  }

  getAllPostsByUser(name: string): Observable<PostModel[]> {
    return this.http.get<PostModel[]>(`${API}/api/posts/` + name);
  }
}
