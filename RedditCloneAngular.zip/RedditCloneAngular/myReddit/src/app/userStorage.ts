export class userStorage {
    email!:string;
    name!:string;
    id!:number;
}