import { CommentPayload } from './comment-payload';

describe('CommentPayload', () => {
  it('should create an instance', () => {
    expect(new CommentPayload()).toBeTruthy();
  });
});
