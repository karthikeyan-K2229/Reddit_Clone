import { Component } from '@angular/core';
import { SubredditService } from '../subreddit.service';
import { SubredditModel } from '../subreddit';
import { throwError } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-subreddit',
  templateUrl: './list-subreddit.component.html',
  styleUrl: './list-subreddit.component.css'
})
export class ListSubredditComponent {

  subreddits!:SubredditModel[];
  constructor(private subredditService: SubredditService,private router:Router) { }

  ngOnInit() {
    this.subredditService.getAllSubreddits().subscribe(data => {
      this.subreddits = data;
    }, error => {
      throwError(error);
    })
  }

  discard() {
    this.router.navigateByUrl('/Home');
  }
}
