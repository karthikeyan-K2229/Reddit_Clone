import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SubredditModel } from '../subreddit';
import { SubredditService } from '../subreddit.service';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-subreddit',
  templateUrl: './subreddit.component.html',
  styleUrl: './subreddit.component.css'
})
export class SubredditComponent {

  createSubredditForm:any;
  userID:any;
  

  constructor(private formBuilder: FormBuilder,private router: Router, private subredditService: SubredditService,private loginservice:LoginService) {
    this.forms();
  }

forms(){
  this.createSubredditForm = this.formBuilder.group({
    name: ['', Validators.required],
    description: ['', Validators.required],
    userId:[localStorage.getItem('userId')]

  });}

  ngOnInit() {
    this.userID=localStorage.getItem('userId');
  }

  discard() {
    this.router.navigateByUrl('/Home');
  }

  createSubreddit() {
    console.log(this.createSubredditForm.value);
    console.log(this.loginservice.User)
    this.subredditService.createSubreddit(this.createSubredditForm.value).subscribe(
   data=>
   {
     console.log(data)
   this.router.navigate(['/Home']);
    },
    (error:{error:any;})=>{
     alert("Registration Failed");
     
    })
  }
}
