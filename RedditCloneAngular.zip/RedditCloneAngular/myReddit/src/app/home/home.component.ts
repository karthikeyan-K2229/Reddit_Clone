import { Component } from '@angular/core';
import { PostService } from '../post.service';
import { PostModel } from '../postModel';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {
  
  posts!:PostModel[];

  constructor(private postService: PostService) {
      this.postService.getAllPosts().subscribe(post=>{
      this.posts = post;
      console.log(this.posts)
    })
   }

  ngOnInit(): void {
  }
}
