import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';
import { SubredditComponent } from './subreddit/subreddit.component';
import { CreatePostComponent } from './create-post/create-post.component';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { ListSubredditComponent } from './list-subreddit/list-subreddit.component';
import { ViewPostComponent } from './view-post/view-post.component';
import { HomeComponent } from './home/home.component';
import { PostTitleComponent } from './post-title/post-title.component';
import { SideBarComponent } from './side-bar/side-bar.component';
import { SubredditSideBarComponent } from './subreddit-side-bar/subreddit-side-bar.component';
import { HeaderComponent } from './header/header.component';

@NgModule({
  declarations: [
    AppComponent,
    SignupComponent,
    LoginComponent,
    SubredditComponent,
    CreatePostComponent,
    ListSubredditComponent,
    ViewPostComponent,
    HomeComponent,
    PostTitleComponent,
    SideBarComponent,
    SubredditSideBarComponent,
    HeaderComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,

  ],
  providers: [
  
    provideAnimationsAsync()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
