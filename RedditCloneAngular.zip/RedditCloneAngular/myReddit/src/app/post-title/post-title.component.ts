import { Component, Input } from '@angular/core';
import { PostModel } from '../postModel';
import { Router } from '@angular/router';


@Component({
  selector: 'app-post-title',
  templateUrl: './post-title.component.html',
  styleUrl: './post-title.component.css'
})
export class PostTitleComponent {


  @Input() posts!: PostModel[];

  constructor(private router:Router) {
    
   }

  ngOnInit(): void {
  }

  goToPost(id: number):void{
    console.log(id)
    this.router.navigateByUrl('/view-post/'+id);
  }
}
