export class CommentPayload{
    text!: string;
    postId!: number;
    userName?:string;
    duration?: string;
}