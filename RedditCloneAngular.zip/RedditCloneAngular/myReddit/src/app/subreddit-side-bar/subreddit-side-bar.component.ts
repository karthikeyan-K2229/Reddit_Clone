import { Component } from '@angular/core';
import { SubredditModel } from '../subreddit';
import { SubredditService } from '../subreddit.service';

@Component({
  selector: 'app-subreddit-side-bar',
  templateUrl: './subreddit-side-bar.component.html',
  styleUrl: './subreddit-side-bar.component.css'
})
export class SubredditSideBarComponent {
  subreddits!: Array<SubredditModel>;
  displayViewAll!: boolean;

  constructor(private subredditService: SubredditService) {
    this.subredditService.getAllSubreddits().subscribe(data=>{
        if(data.length>=4){
          this.subreddits = data.splice(0,3);
          this.displayViewAll = true;
        }else{
          this.subreddits = data;
        }
    });
   }

  ngOnInit(): void {
  }

}
