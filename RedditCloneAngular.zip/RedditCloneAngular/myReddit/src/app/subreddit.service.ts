import { Injectable } from '@angular/core';
import { SubredditModel } from './subreddit';
import { Observable } from 'rxjs';
import { environment } from './environments/environment';
import { HttpClient } from '@angular/common/http';


const API = environment.apiURL;
@Injectable({
  providedIn: 'root'
})
export class SubredditService {
 
  constructor(private httpClient: HttpClient) { }

  createSubreddit(subredditModel: SubredditModel): Observable<object> {
      console.log(subredditModel);
    return this.httpClient.post(`${API}/createSubreddit`,subredditModel);
  }
  
  getAllSubreddits(): Observable<Array<SubredditModel>> {
    return this.httpClient.get<Array<SubredditModel>>(`${API}/getAllSubreddit`);
  }


}
