import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PostModel } from '../postModel';
import { CommentPayload } from '../comment-payload';
import { ActivatedRoute, Router } from '@angular/router';
import { PostService } from '../post.service';
import { CommentService } from '../comment.service';
import { throwError } from 'rxjs';

@Component({
  selector: 'app-view-post',
  templateUrl: './view-post.component.html',
  styleUrl: './view-post.component.css'
})
export class ViewPostComponent {
  constructor(private postService: PostService, private activateRoute: ActivatedRoute,
    private commentService: CommentService, private router: Router,private formBuilder: FormBuilder,) {
    this.postId = this.activateRoute.snapshot.params['id'];
    this.forms();
    }

  postId!: number;
  post!: PostModel;
  commentForm!: FormGroup;
  commentPayload!: CommentPayload;
  comments!: CommentPayload[];
  PostForm:any

  ngOnInit(): void {
    this.getPostById();
    this.getCommentsForPost();
  }

  forms(){
    this.PostForm = this.formBuilder.group({
      text: ['', Validators.required],
      userName: [localStorage.getItem('username')],
      postId : [this.activateRoute.snapshot.params['id']]
    });}

  postComment() {
    console.log(this.PostForm.value);
    this.commentService.postComment(this.PostForm.value).subscribe(
   data=>
   {
     console.log(data)
     alert("Comment saved Successfully");
    },
    (error:{error:any;})=>{
     alert("Registration Failed");
     
    })
  }

  private getPostById() {
    this.postService.getPost(this.postId).subscribe(data => {
      this.post = data;
console.log(this.post)
    }, error => {
      throwError(error);
    });
  }

  private getCommentsForPost() {
    this.commentService.getAllCommentsForPost(this.postId).subscribe(data => {
      this.comments = data;
    }, error => {
      throwError(error);
    });
  }
}
