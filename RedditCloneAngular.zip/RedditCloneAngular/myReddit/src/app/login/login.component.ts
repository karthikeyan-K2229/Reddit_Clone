import { Component } from '@angular/core';
import { signup } from '../signup/signup';
import { Router } from '@angular/router';
import { FormBuilder, Validators } from '@angular/forms';
import { LoginService } from '../login.service';
import { userStorage } from '../userStorage';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  public loginForm: any;
  msg="";
  submitted:boolean=false;

  constructor(private loginService: LoginService,private _router : Router,private formBuilder: FormBuilder) 
   {
      this.forms();
   }

  ngOnInit(): void {
  }


   forms(){
    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.required,Validators.email]],
      password: ['', [ Validators.required]],
    });
  }
  
  
  userLogin(){
    this.submitted = true;
    if (this.loginForm.invalid) {
      alert("Enter all details");
      return;
    }
    console.log(this.loginForm.value);
    

     this.loginService.LoginUser(this.loginForm.value).subscribe((data:any)=>{

       console.log(data);
        localStorage.setItem('username',data.username)
        localStorage.setItem('userId',data.userId)
        alert("login successfull")
        this._router.navigate(['/Home']);
         let user:userStorage={
         name: data["username"],
         id:data["userId"],
         email:data["email"]
       }
      console.log(user)
       this.loginService.SetUser(user);
       
    
     
         },
         (error:{error:any;})=>{
         this.msg="Invalid credentials";
        // window.location.reload();
        //this._router.navigate(['/register']);
         alert("Invalid credentials");
         ()=>alert("invalid credentials");
         })
     }
}
